package com.randude14.hungergames;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

public class Config {
	private final Plugin plugin;
	
	public Config(final Plugin plugin) {
		this.plugin = plugin;
	}
	
	public String getJoinMessage() {
		return plugin.getConfig().getString("properties.join-message");
	}
	
	public String getLeaveMessage() {
		return plugin.getConfig().getString("properties.leave-message");
	}
	
	public String getKillMessage() {
		return plugin.getConfig().getString("properties.kill-message");
	}
	
	public String getDefaultGame() {
		return plugin.getConfig().getString("properties.default-game");
	}
	
	public List<ItemStack> getChestLoot() {
		plugin.reloadConfig();
		FileConfiguration config = plugin.getConfig();
		List<ItemStack> items = new ArrayList<ItemStack>();
		ConfigurationSection itemSection = config.getConfigurationSection("chest-loot");
		if(itemSection == null) {
			return items;
		}
		for(String key : itemSection.getKeys(false)) {
			ConfigurationSection section = itemSection.getConfigurationSection(key);
			Material mat = Material.getMaterial(key);
			if(mat == null)
				continue;
			int stackSize = section.getInt("stack-size", 1);
			ItemStack item;
			if(section.isInt("data")) {
				byte data = new Integer(section.getInt("data")).byteValue();
				item = new ItemStack(mat, stackSize, data);
			}
			
			else {
				item = new ItemStack(mat, stackSize);
			}
			
			for(String str : section.getKeys(false)) {
				Enchantment enchant = Enchantment.getByName(str);
				if(enchant == null || !enchant.canEnchantItem(item)) {
					continue;
				}
				int level = section.getInt(str, 1);
				try {
					item.addEnchantment(enchant, level);
				} catch (Exception ex) {
				}
				
			}
			items.add(item);
		}
		return items;
	}
	
	public Map<ItemStack, Double> getSponsorLoot() {
		plugin.reloadConfig();
		FileConfiguration config = plugin.getConfig();
		Map<ItemStack, Double> sponsorLoot = new HashMap<ItemStack, Double>();
		ConfigurationSection itemSection = config.getConfigurationSection("sponsor-loot");
		if(itemSection == null) {
			return sponsorLoot;
		}
		for(String key : itemSection.getKeys(false)) {
			ConfigurationSection section = itemSection.getConfigurationSection(key);
			Material mat = Material.getMaterial(key);
			if(mat == null)
				continue;
			int stackSize = section.getInt("stack-size", 1);
			double money = section.getDouble("money", 10.00);
			ItemStack item;
			if(section.isInt("data")) {
				byte data = new Integer(section.getInt("data")).byteValue();
				item = new ItemStack(mat, stackSize, data);
			}
			
			else {
				item = new ItemStack(mat, stackSize);
			}
			
			for(String str : section.getKeys(false)) {
				Enchantment enchant = Enchantment.getByName(str);
				if(enchant == null || !enchant.canEnchantItem(item)) {
					continue;
				}
				int level = section.getInt(str, 1);
				try {
					item.addEnchantment(enchant, level);
				} catch (Exception ex) {
				}
				
			}
			sponsorLoot.put(item, money);
		}
		return sponsorLoot;
		
	}
	
}
